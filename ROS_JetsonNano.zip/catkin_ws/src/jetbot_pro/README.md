# jetbot_pro

A ROS package of the WaveShare JetBot ROS AI Kit. An educational AI robot based on NVIDIA Jetson Nano.

http://www.waveshare.net/shop/JetBot-ROS-AI-Kit.htm

http://www.waveshare.com/JetBot-ROS-AI-Kit.htm
